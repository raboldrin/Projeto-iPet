(function($) {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = APP_URL+'server/php/';


    function slug(str) {
      if( str == null ) return;
      str = str.replace(/^\s+|\s+$/g, ''); // trim
      str = str.toLowerCase();

      // remove accents, swap ñ for n, etc
      var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
      var to   = "aaaaaeeeeeiiiiooooouuuunc------";
      for (var i=0, l=from.length ; i<l ; i++) {
        str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
      }

      str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
        .replace(/\s+/g, '-') // collapse whitespace and replace by -
        .replace(/-+/g, '-'); // collapse dashes

      return str;
    };

    function initCustomImageName() {
        var countImages = $('#image-container').children().length;
        var customFileName = slug( $('#name').val() );
        var id = $('#id').val();
        $('#custom-filename').val(id+'_'+customFileName+'_'+countImages);
    }

    $(document).ready(function(){
        initCustomImageName();
    });


    $('#fileupload').fileupload({
        url: url,
        dataType: 'json',
        done: function(e, data) {
            initCustomImageName();
        }
    })
    .prop('disabled', !$.support.fileInput).parent().addClass($.support.fileInput ? undefined : 'disabled')
    .bind('fileuploadsubmit', function (e, data) {
        var customFileName = $('#custom-filename').val(),
            productID      = $('#id').val();

        data.formData = {customFileName: customFileName, productID: productID};
        console.log(data);
    });

    $('#image-container').on('click', '.delete', function(){
        var _this = $(this),
            deleteURL = $(this).attr('data-href'),
            productID = $(this).attr('data-product');

        console.log(deleteURL);

        $.ajax({
            url: deleteURL,
            dataType: 'json',
            formData: { productID: productID },
            type: 'DELETE',

            success: function(data) {
                console.log(data);
                _this.parent().parent().remove();
            }
        });

    });

    $('#fileupload').change(function(e){
        loadImage(
            e.target.files[0],
            function (img) {
                $('#image-container').append(img);
                $('#image-container > img').wrap('<div class="col-xs-6 col-md-3"><div class="thumbnail"></div></div>');
            },
            {maxWidth: 348, maxHeight: 348} // Options
        );
    });


    $(document).on('click', '.label-default', function(e) {
        e.preventDefault();

        var _this      = $(this),
            list_id    = $(this).attr('data-list-id'),
            product_id = $(this).attr('data-product-id');

        $.ajax({
            url: APP_URL + 'Lista/ProductToList',
            dataType: 'json',
            type: 'POST',
            data: { list_id: list_id, product_id: product_id },

            success: function(data) {
                _this.toggleClass('label-warning');
                _this.toggleClass('label-default');
            }
        });
    });

    $(document).on('click', '.label-warning', function(e) {
        e.preventDefault();

        var _this      = $(this),
            list_id    = $(this).attr('data-list-id'),
            product_id = $(this).attr('data-product-id');

        $.ajax({
            url: APP_URL + 'Lista/ProductToTrash',
            dataType: 'json',
            type: 'POST',
            data: { list_id: list_id, product_id: product_id },

            success: function(data) {
                _this.toggleClass('label-warning');
                _this.toggleClass('label-default');
            }
        });
    });
})(jQuery);