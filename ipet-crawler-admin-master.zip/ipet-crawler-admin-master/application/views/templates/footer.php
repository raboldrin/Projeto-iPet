<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
    <script> var APP_URL = '<?php echo base_url(); ?>';</script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
    <script src="<?php echo base_url('assets/js/vendor/jquery.ui.widget.js'); ?>"></script>
    <!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
    <script src="<?php echo base_url('assets/js/jquery.iframe-transport.js'); ?>"></script>
    <!-- The basic File Upload plugin -->
    <script src="<?php echo base_url('assets/js/jquery.fileupload.js'); ?>"></script>
    <script src="<?php echo base_url('assets/js/load-image.all.min.js'); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <!-- Main -->
    <script src="<?php echo base_url('assets/js/main.min.js'); ?>"></script>
  </body>
</html>