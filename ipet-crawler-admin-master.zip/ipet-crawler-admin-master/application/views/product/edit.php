<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php foreach( $product as $detail ) { ?>
  <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li><a href="<?php echo site_url('produtos'); ?>">Voltar</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h3 class="page-header"><?php echo $detail['name']; ?></h3>

          <span class="label label-default">Criado: <?php echo date('d\/m\/Y H:i:s', strtotime( $detail['insert_date'] ) ); ?></span>
          <?php if( isset( $detail['update_date'] ) ) { echo '<span class="label label-default">Editado: ' . date('d\/m\/Y H:i:s', strtotime( $detail['update_date'] ) ) . '</span>'; } ?>
          <br><br>

          <form method="POST" action="<?php echo site_url('/Product/update/'.$detail['id']); ?>">
            <div class="form-group">
              <div class="row">

                <div class="col-xs-2">
                  <label for="id">ID</label>
                  <input type="text" class="form-control" id="id" name="id" placeholder="ID" value="<?php echo $detail['id']; ?>" readonly>
                </div>

                <div class="col-xs-8">
                  <label for="original_url">URL Original</label>
                  <input type="text" class="form-control" id="original_url" name="original_url" placeholder="ID" value="<?php echo $detail['original_url']; ?>" readonly>
                </div>

               <div class="col-xs-2">
                  <label for="price">Preço</label>
                  <input type="text" class="form-control" id="price" name="price" placeholder="ID" value="<?php echo $detail['price']; ?>" readonly>
                </div>

              </div>
            </div>

            <?php $images = json_decode( html_entity_decode($detail['images']) ); ?>

            <div class="form-group">
              <div class="row" id="image-container">
                  <?php foreach( $images as $image ) { ?>
                  <div class="col-xs-6 col-md-3">
                    <div class="thumbnail">
                      <div class="text-danger delete" data-type="DELETE" data-product="<?php echo $detail['id']; ?>" data-href="<?php echo site_url('/server/php/index.php?file=') . $image . '&product_id=' . $detail['id']; ?>"><i class="glyphicon glyphicon-remove"></i></div>
                      <img src="<?php echo base_url('/uploads/'.$image); ?>" alt="<?php echo $image; ?>">
                    </div>
                  </div>
                  <?php } ?>
              </div>

              <div class="row">
                  <div class="col-xs-6 col-md-3">
                    <span class="btn btn-success fileinput-button">
                        <i class="glyphicon glyphicon-plus"></i>
                        <span>Adicionar Imagens</span>
                        <input id="fileupload" type="file" name="files[]">
                    </span>
                  </div>
              </div>
            </div>

            <div class="form-group">
              <label for="name">Nome</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Nome" value="<?php echo $detail['name']; ?>">
              <input id="custom-filename" type="hidden" name="custom-filename" value="<?php echo $detail['id'] . '_' . $detail['name']; ?>" class="form-control">
            </div>

            <div class="form-group">
              <label for="name">Marca</label>
              <input type="text" class="form-control" id="brand" name="brand" placeholder="Marca" value="<?php echo $detail['brand']; ?>">
            </div>

            <div class="form-group">
              <div class="row">
                <div class="col-xs-3">
                  <label for="category_1">Categoria 1</label>
                  <input type="text" class="form-control" id="category_1" name="category_1" placeholder="Categoria 1" value="<?php echo $detail['category_1']; ?>">
                </div>
                <div class="col-xs-3">
                  <label for="category_2">Categoria 2</label>
                  <input type="text" class="form-control" id="category_2" name="category_2" placeholder="Categoria 2" value="<?php echo $detail['category_2']; ?>">
                </div>
                <div class="col-xs-3">
                  <label for="category_3">Categoria 3</label>
                  <input type="text" class="form-control" id="category_3" name="category_3" placeholder="Categoria 3" value="<?php echo $detail['category_3']; ?>">
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="excerpt">Resumo</label>
              <textarea type="text" class="form-control" id="excerpt" name="excerpt" placeholder="Resumo" rows="8"><?php echo $detail['excerpt']; ?></textarea>
            </div>

            <?php $description = json_decode( html_entity_decode($detail['description']) ); ?>

            <div class="form-group">
              <label for="description">Descrição</label>
              <textarea type="text" class="form-control" id="description" name="description" placeholder="Descrição" rows="8"><?php if( is_array( $description ) ) { echo implode("\n", $description); } else { echo $detail['description']; } ?></textarea>
            </div>

           <div class="form-group">
              <label for="tips">Dicas</label>
              <textarea type="text" class="form-control" id="tips" name="tips" placeholder="Dicas" rows="8"><?php echo $detail['tips']; ?></textarea>
            </div>

           <?php $specs = json_decode( html_entity_decode($detail['specs']) ); ?>

           <div class="form-group">
              <label for="specs">Especificações</label>
              <textarea type="text" class="form-control" id="specs" name="specs" placeholder="Especificações" rows="8"><?php if( is_array( $specs ) ) { echo implode("\n", $specs); } else { echo $detail['specs']; } ?></textarea>
            </div>

            <div class="form-group">
              <div class="row">
                <div class="col-xs-2">
                  <label for="weight">Peso (kg)</label>
                  <input type="number" class="form-control" id="weight" name="weight" placeholder="0" value="<?php echo $detail['weight']; ?>" step="any">
                </div>
              </div>
            </div>

            <div class="form-group">
              <div class="row">
                <div class="col-xs-2">
                  <label for="">Comprimento (cm)</label>
                  <input type="number" class="form-control" id="length" name="length" placeholder="Comprimento" value="<?php echo $detail['length']; ?>" step="any">
                </div>

                <div class="col-xs-2">
                  <label for="">Largura (cm)</label>
                  <input type="number" class="form-control" id="width" name="width" placeholder="Largura" value="<?php echo $detail['width']; ?>" step="any">
                </div>

                <div class="col-xs-2">
                  <label for="">Altura (cm)</label>
                  <input type="number" class="form-control" id="height" name="height" placeholder="Altura" value="<?php echo $detail['height']; ?>" step="any">
                </div>
              </div>
            </div>

            <button type="submit" class="btn btn-primary">Atualizar</button>
          </form>
        </div>
      </div>
    </div>
    <?php } ?>