<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php // foreach( $product as $detail ) { ?>
  <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li><a href="<?php echo site_url('produtos'); ?>">Voltar</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h3 class="page-header">Adicionar novo produto</h3>

          <form method="POST" action="<?php echo site_url('/Product/insert'); ?>">

            <div class="form-group">
              <label for="name">Nome</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Nome">
            </div>

            <div class="form-group">
              <label for="name">Marca</label>
              <input type="text" class="form-control" id="brand" name="brand" placeholder="Marca">
            </div>

            <div class="form-group">
              <div class="row">
                <div class="col-xs-3">
                  <label for="category_1">Categoria 1</label>
                  <input type="text" class="form-control" id="category_1" name="category_1" placeholder="Categoria 1">
                </div>
                <div class="col-xs-3">
                  <label for="category_2">Categoria 2</label>
                  <input type="text" class="form-control" id="category_2" name="category_2" placeholder="Categoria 2">
                </div>
                <div class="col-xs-3">
                  <label for="category_3">Categoria 3</label>
                  <input type="text" class="form-control" id="category_3" name="category_3" placeholder="Categoria 3">
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="excerpt">Resumo</label>
              <textarea type="text" class="form-control" id="excerpt" name="excerpt" placeholder="Resumo" rows="8"></textarea>
            </div>

            <div class="form-group">
              <label for="description">Descrição</label>
              <textarea type="text" class="form-control" id="description" name="description" placeholder="Descrição" rows="8"></textarea>
            </div>

           <div class="form-group">
              <label for="tips">Dicas</label>
              <textarea type="text" class="form-control" id="tips" name="tips" placeholder="Dicas" rows="8"></textarea>
            </div>

           <div class="form-group">
              <label for="specs">Especificações</label>
              <textarea type="text" class="form-control" id="specs" name="specs" placeholder="Especificações" rows="8"></textarea>
            </div>

            <div class="form-group">
              <div class="row">
                <div class="col-xs-2">
                  <label for="weight">Peso (kg)</label>
                  <input type="number" class="form-control" id="weight" name="weight" placeholder="0" step="any">
                </div>
              </div>
            </div>

            <div class="form-group">
              <div class="row">
                <div class="col-xs-2">
                  <label for="">Comprimento (cm)</label>
                  <input type="number" class="form-control" id="length" name="length" placeholder="Comprimento" step="any">
                </div>

                <div class="col-xs-2">
                  <label for="">Largura (cm)</label>
                  <input type="number" class="form-control" id="width" name="width" placeholder="Largura" step="any">
                </div>

                <div class="col-xs-2">
                  <label for="">Altura (cm)</label>
                  <input type="number" class="form-control" id="height" name="height" placeholder="Altura" step="any">
                </div>
              </div>
            </div>

            <button type="submit" class="btn btn-primary">Adicionar</button>
          </form>
        </div>
      </div>
    </div>
    <?php //} ?>