<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php $this->session->sess_destroy(); redirect('login'); ?>