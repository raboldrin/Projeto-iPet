<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <h5>Total de listas <span class="badge"><?php echo $total_products; ?></span></h5>

        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Listas</h1>

          <div id="products-list">
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th style="width: 90px">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if( !empty( $products ) ) : foreach( $products as $product ) : ?>
                  <tr>
                    <td><?php echo $product['id']; ?></td>
                    <td>
                      <a href="<?php echo site_url('/lista/') . $product['id']; ?>"><?php echo $product['name']; ?></a>
                      </td>
                    <td>
                      <a href="<?php echo site_url('/listas/copiar/') . $product['id']; ?>" class="btn btn-sm btn-primary"><div class="glyphicon glyphicon-duplicate"></div></a> <a href="<?php echo site_url('/listas/deletar/') . $product['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza?')"><div class="glyphicon glyphicon-remove"></div></a>
                    </td>
                  </tr>
                  <?php endforeach; endif; ?>
                </tbody>
              </table>
            </div>
            <nav aria-label="Page navigation" class="text-center">
              <?php echo $this->ajax_pagination->create_links(); ?>
            </nav>
          </div>
        </div>
      </div>
    </div>