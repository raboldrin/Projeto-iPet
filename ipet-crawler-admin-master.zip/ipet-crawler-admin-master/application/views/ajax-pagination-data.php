            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Marca</th>
                    <th>Categoria 1</th>
                    <th>Categoria 2</th>
                    <th>Categoria 3</th>
                    <th style="width: 90px">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    if( !empty( $products ) ) {
                      foreach( $products as $product ) {
                  ?>
                  <tr>
                    <td><?php echo $product['id']; ?></td>
                    <td>
                      <a href="<?php echo site_url('/produto/') . $product['id']; ?>"><?php echo $product['name']; ?></a>
                        <div class="product-tags">
                        <?php if( !isset($product['update_date']) ) echo '<span class="label label-success">Novo</span>'; ?>

                          <?php
                              $lists_enabled = $this->List_Model->getAvailable( $product['id'] );
                              if ( (is_array($lists_enabled) ) ) {
                                $ids = array_column($lists_enabled, 'list_id');
                              }

                              foreach ( $lists_available as $list ) {
                                   if ( (is_array($lists_enabled) ) ) {
                                      if ( array_search($list['id'], $ids) !== FALSE) {
                                        $label = 'label-warning';
                                      } else {
                                        $label = 'label-default';
                                      }
                                    } else {
                                      $label = 'label-default';
                                    }

                                   echo '<span class="label '.$label.'" data-list-id="'.$list['id'].'" data-product-id="'.$product['id'].'">'.$list['name'].'</span> ';
                              }
                          ?>
                        </div>
                      </td>
                    <td><a href="<?php echo site_url('/marca/') . $product['slug_brand']; ?>"><?php echo $product['brand']; ?></a></td>
                    <td><a href="<?php echo site_url('/categoria/') . $product['slug_category_1']; ?>"><?php echo $product['category_1']; ?></a></td>
                    <td><a href="<?php echo site_url('/categoria/') . $product['slug_category_2']; ?>"><?php echo $product['category_2']; ?></a></td>
                    <td><a href="<?php echo site_url('/categoria/') . $product['slug_category_3']; ?>"><?php echo $product['category_3']; ?></td>
                    <td>
                      <a href="<?php echo site_url('/produtos/copiar/') . $product['id']; ?>" class="btn btn-sm btn-primary"><div class="glyphicon glyphicon-duplicate"></div></a> <a href="<?php echo site_url('/produtos/deletar/') . $product['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza?')"><div class="glyphicon glyphicon-remove"></div></a>
                    </td>
                  </tr>
                  <?php } } ?>
                </tbody>
              </table>
            </div>
            <nav aria-label="Page navigation" class="text-center">
              <?php echo $this->ajax_pagination->create_links(); ?>
            </nav>