<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

  <div class="row">
    <div class="Absolute-Center is-Responsive">
      <div id="logo-container"></div>
      <div class="col-sm-12 col-md-10 col-md-offset-1">
        <?php $attributes = array('id' => 'loginform', 'name' => 'loginform'); ?>
        <?php echo form_open('Login/index', $attributes); ?>
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
            <input class="form-control" type="text" id="username" name='username' placeholder="username"/>
          </div>
          <div class="form-group input-group">
            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
            <input class="form-control" type="password" id="password" name='password' placeholder="password"/>
          </div>
          <div class="form-group">
            <button type="submit" id="btn-login" name="btn-login" class="btn btn-def btn-block" value="Login">Login</button>
          </div>
        <?php echo form_close(); ?>
        <?php echo $this->session->flashdata('msg'); ?>
      </div>
    </div>
  </div>
