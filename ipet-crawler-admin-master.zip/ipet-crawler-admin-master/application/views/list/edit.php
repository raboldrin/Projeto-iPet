<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php foreach( $product as $detail ) { ?>
  <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li><a href="<?php echo site_url('listas'); ?>">Voltar</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h3 class="page-header"><?php echo $detail['name']; ?></h3>

          <form method="POST" action="<?php echo site_url('/Lista/update/'.$detail['id']); ?>">

            <div class="form-group">
              <label for="name">Nome</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Nome" value="<?php echo $detail['name']; ?>">
              <input type="hidden" class="form-control" id="id" name="id" placeholder="ID" value="<?php echo $detail['id']; ?>" readonly>
            </div>

            <button type="submit" class="btn btn-primary">Atualizar</button>
          </form>
        </div>
      </div>
    </div>
    <?php } ?>