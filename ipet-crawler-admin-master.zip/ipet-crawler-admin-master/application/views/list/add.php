<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php // foreach( $product as $detail ) { ?>
  <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li><a href="<?php echo site_url('listas'); ?>">Voltar</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h3 class="page-header">Adicionar nova lista</h3>

          <form method="POST" action="<?php echo site_url('/Lista/insert'); ?>">

            <div class="form-group">
              <label for="name">Nome</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Nome">
            </div>

            <button type="submit" class="btn btn-primary">Adicionar</button>
          </form>
        </div>
      </div>
    </div>
    <?php //} ?>