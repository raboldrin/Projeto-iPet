<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
  public function __construct() {
     parent::__construct();

     $this->load->library('session');
     $this->load->library('form_validation');
     $this->load->helper('url');
     $this->load->helper('html');
     $this->load->database();

     $this->load->model('Login_Model');
  }

	public function index() {
        $username = $this->input->post("username");
        $password = $this->input->post("password");

        $this->form_validation->set_rules("username", "Username", "trim|required");
        $this->form_validation->set_rules("password", "Password", "trim|required");

        if ( $this->form_validation->run() == FALSE ) {
            $this->load->view('templates/header');
            $this->load->view('login');
            $this->load->view('templates/footer');
        } else {
            if ($this->input->post('btn-login') == "Login") {
                $usr_result = $this->Login_Model->get_user($username, $password);

                if ($usr_result > 0) {
                    $sessiondata = array('username' => $username, 'is_logged_in' => TRUE);
                    $this->session->set_userdata($sessiondata);
                    redirect('produtos');
                } else {
                    $this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Invalid username and password!</div>');
                }
            } else {
                redirect('login');
            }
        }


	}
}
