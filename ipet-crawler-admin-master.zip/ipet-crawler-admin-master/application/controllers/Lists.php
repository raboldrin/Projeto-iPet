<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lists extends CI_Controller {
  public function __construct() {
     parent::__construct();
     $this->load->helper('url');
     $this->load->model('List_Model');
     $this->load->library('session');
     $this->load->library('Ajax_Pagination');
     $this->perPage = 100;
  }

    public function index() {
        $data = array();
        $totalRec = count( $this->List_Model->getRows() );
        // $totalEdited = $this->List_Model->getEdited();

        $config['target']      = '#products-list';
        $config['base_url']    = base_url().'Products/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        // $this->ajax_pagination->initialize($config);

        $data['products'] = $this->List_Model->getRows( array( 'limit' => $this->perPage ) );
        // $data['brands'] = $this->List_Model->getCategories( 'brand, slug_brand' );
        $data['total_products'] = $totalRec;
        // $data['total_edited'] = ( $totalEdited == 0 ) ? 0 : count( $totalEdited );

        if ($this->session->userdata('is_logged_in') == TRUE) {
            $this->load->view('templates/header');
            $this->load->view('templates/nav-bar');
            $this->load->view('lists', $data);
            $this->load->view('templates/footer');
        } else {
            redirect('login');
        }
    }

    public function categoria( $cat ) {

        $data = array();
        if ( $cat ) {
            $totalRec = count( $this->List_Model->getRows( array('where' => $cat) ) );
            $totalEdited = $this->List_Model->getEdited( array('where' => $cat) );
        } else {
            $totalRec = count( $this->List_Model->getRows() );
            $totalEdited = $this->List_Model->getEdited();
        }

        $config['target']      = '#products-list';
        $config['base_url']    = base_url().'Products/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['cat']    = $cat;
        $this->ajax_pagination->initialize($config);

        $data['products'] = $this->List_Model->getRows( array( 'limit' => $this->perPage, 'where' => $cat ) );
        $data['brands'] = $this->List_Model->getCategories( 'brand, slug_brand' );
        $data['total_products'] = $totalRec;
        $data['total_edited'] = ( $totalEdited == 0 ) ? 0 : count( $totalEdited );

        if ($this->session->userdata('is_logged_in') == TRUE) {
            $this->load->view('templates/header');
            $this->load->view('templates/nav-bar');
            $this->load->view('products', $data);
            $this->load->view('templates/footer');
        } else {
            redirect('login');
        }

    }

    public function marca( $cat ) {

        $data = array();
        if ( $cat ) {
            $totalRec = count( $this->List_Model->getRows( array('where' => $cat) ) );
            $totalEdited = $this->List_Model->getEdited( array('where' => $cat) );
        } else {
            $totalRec = count( $this->List_Model->getRows() );
            $totalEdited = $this->List_Model->getEdited();
        }


        $config['target']      = '#products-list';
        $config['base_url']    = base_url().'Products/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['cat']    = $cat;
        $this->ajax_pagination->initialize($config);

        $data['products'] = $this->List_Model->getRows( array( 'limit' => $this->perPage, 'where' => $cat ) );
        $data['brands'] = $this->List_Model->getCategories( 'brand, slug_brand' );
        $data['total_products'] = $totalRec;
        $data['total_edited'] = ( $totalEdited == 0 ) ? 0 : count( $totalEdited );

        if ($this->session->userdata('is_logged_in') == TRUE) {
            $this->load->view('templates/header');
            $this->load->view('templates/nav-bar');
            $this->load->view('products', $data);
            $this->load->view('templates/footer');
        } else {
            redirect('login');
        }

    }

    function ajaxPaginationData() {
        $page = $this->input->post('page');
        if( !$page ) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        $cat = $this->input->post('cat');

        //total rows count

        if( $cat ) {
            $totalRec = count( $this->List_Model->getRows(array('where' => $cat)) );
        } else {
            $totalRec = count( $this->List_Model->getRows() );
        }

        //pagination configuration
        $config['target']      = '#products-list';
        $config['base_url']    = base_url().'Products/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;

        if( $cat ) {
            $config['cat']    = $cat;
        }

        $this->ajax_pagination->initialize($config);

        //get the posts data

        if( $cat ) {
            $data['products'] = $this->List_Model->getRows( array( 'start' => $offset, 'limit' => $this->perPage, 'where' => $cat) );
        } else {
            $data['products'] = $this->List_Model->getRows( array( 'start' => $offset, 'limit' => $this->perPage ) );
        }

        //load the view
        $this->load->view('ajax-pagination-data', $data, false);
    }

}
