<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lista extends CI_Controller {
  public function __construct() {
     parent::__construct();
     $this->load->library('session');
     $this->load->helper('url', 'y2');
     $this->load->model('List_Model');
  }

    public function edit( $id ) {
        $data = array();
        $data['product'] = $this->List_Model->edit( $id );
        if ($this->session->userdata('is_logged_in') == TRUE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/nav-bar');
            $this->load->view('list/edit', $data);
            $this->load->view('templates/footer', $data);
        } else {
            redirect('login');
        }
    }

    public function update( $id ) {
        $data = array();
        $id                       = $this->input->post('id');
        $data['name']             = $this->input->post('name');

        $this->List_Model->update( $data, $id );

        redirect( site_url( '/lista/'. $id ) );
    }

    public function add() {
        $data = array();
        if ($this->session->userdata('is_logged_in') == TRUE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/nav-bar');
            $this->load->view('list/add', $data);
            $this->load->view('templates/footer', $data);
        } else {
            redirect('login');
        }
    }

    public function insert() {
        $data['name']             = $this->input->post('name');

        if ( $id = $this->List_Model->add( $data ) ) {
            redirect( site_url( '/listas/') );
        }
    }

    public function copy( $id ) {
        if ( $id = $this->List_Model->copy( 'lists', 'id', $id ) ) {
            redirect( site_url( '/lista/'. $id ) );
        }
    }

    public function delete( $id ) {
        if ( $this->List_Model->delete( $id ) ) {
            redirect( site_url( '/listas/') );
        }
    }

    public function ProductToList() {
        $data['list_id']    = $this->input->post('list_id');
        $data['product_id'] = $this->input->post('product_id');
        if( $this->List_Model->addProduct( $data ) ) {
            header('Content-Type: application/json');
            echo json_encode( array('success' => true) );
        }
    }

    public function ProductToTrash() {
        $data['list_id']    = $this->input->post('list_id');
        $data['product_id'] = $this->input->post('product_id');
        if( $this->List_Model->removeProduct( $data ) ) {
            header('Content-Type: application/json');
            echo json_encode( array('success' => true) );
        }
    }
}
