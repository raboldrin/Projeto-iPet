<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
  public function __construct() {
     parent::__construct();
     $this->load->library('session');
     $this->load->helper('url', 'y2');
     $this->load->model('Product_Model');
  }

    public function edit( $id ) {
        $data = array();
        $data['product'] = $this->Product_Model->edit( $id );
        if ($this->session->userdata('is_logged_in') == TRUE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/nav-bar');
            $this->load->view('product/edit', $data);
            $this->load->view('templates/footer', $data);
        } else {
            redirect('login');
        }
    }

    public function update( $id ) {
        $data = array();
        $id                       = $this->input->post('id');
        $data['name']             = $this->input->post('name');
        $data['brand']            = $this->input->post('brand');
        $data['slug_brand']       = remove_accents($this->input->post('brand'));
        $data['category_1']       = $this->input->post('category_1');
        $data['slug_category_1']  = remove_accents($this->input->post('category_1'));
        $data['category_2']       = $this->input->post('category_2');
        $data['slug_category_2']  = remove_accents($this->input->post('category_2'));
        $data['category_3']       = $this->input->post('category_3');
        $data['slug_category_3']  = remove_accents($this->input->post('category_3'));
        $data['excerpt']          = $this->input->post('excerpt');
        $data['description']      = $this->input->post('description');
        $data['tips']             = $this->input->post('tips');
        $data['specs']            = $this->input->post('specs');
        $data['weight']           = $this->input->post('weight');
        $data['length']           = $this->input->post('length');
        $data['width']            = $this->input->post('width');
        $data['height']           = $this->input->post('height');

        $this->Product_Model->update( $data, $id );

        redirect( site_url( '/produto/'. $id ) );
    }

    public function add() {
        $data = array();
        if ($this->session->userdata('is_logged_in') == TRUE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/nav-bar');
            $this->load->view('product/add', $data);
            $this->load->view('templates/footer', $data);
        } else {
            redirect('login');
        }
    }

    public function insert() {
        $data['name']             = $this->input->post('name');
        $data['brand']            = $this->input->post('brand');
        $data['slug_brand']       = remove_accents($this->input->post('brand'));
        $data['category_1']       = $this->input->post('category_1');
        $data['slug_category_1']  = remove_accents($this->input->post('category_1'));
        $data['category_2']       = $this->input->post('category_2');
        $data['slug_category_2']  = remove_accents($this->input->post('category_2'));
        $data['category_3']       = $this->input->post('category_3');
        $data['slug_category_3']  = remove_accents($this->input->post('category_3'));
        $data['images']           = json_encode(array());
        $data['excerpt']          = $this->input->post('excerpt');
        $data['description']      = $this->input->post('description');
        $data['tips']             = $this->input->post('tips');
        $data['specs']            = $this->input->post('specs');
        $data['weight']           = $this->input->post('weight');
        $data['length']           = $this->input->post('length');
        $data['width']            = $this->input->post('width');
        $data['height']           = $this->input->post('height');

        if ( $id = $this->Product_Model->add( $data ) ) {
            redirect( site_url( '/produto/'. $id ) );
        }
    }

    public function copy( $id ) {
        if ( $id = $this->Product_Model->copy( 'products', 'id', $id ) ) {
            redirect( site_url( '/produto/'. $id ) );
        }
    }

    public function delete( $id ) {
        if ( $this->Product_Model->delete( $id ) ) {
            redirect( site_url( '/produtos/') );
        }
    }
}
