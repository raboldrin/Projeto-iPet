<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class List_Model extends CI_Model {
    public function __construct() {
      parent::__construct();

    }

    function getRows( $params = array() ) {
        $this->db->select('*');
        $this->db->from('lists');

        $this->db->order_by( 'name' , 'asc' );

        if( array_key_exists( 'start', $params ) && array_key_exists( 'limit', $params ) ) {

            $this->db->limit( $params['limit'], $params['start'] );

        } else if( !array_key_exists( 'start', $params ) && array_key_exists( 'limit', $params ) ) {

            $this->db->limit( $params['limit'] );
        }

        $query = $this->db->get();

        return ( $query->num_rows() > 0 ) ? $query->result_array() : FALSE;
    }

    function edit( $id ) {
        $this->db->select('*');
        $this->db->from('lists');
        $this->db->where('id', $id);

        $query = $this->db->get();

        return ( $query->num_rows() > 0 ) ? $query->result_array() : FALSE;
    }

    function add( $data ) {
        $this->db->insert('lists', $data);
        $insert_id = $this->db->insert_id();

        return $insert_id;
    }

    function update( $data, $id ) {
        $this->db->where( 'id', $id );
        $this->db->update('lists', $data);
    }


    function copy($table, $primary_key_field, $primary_key_val) {
       /* generate the select query */
       $this->db->where($primary_key_field, $primary_key_val);
       $query = $this->db->get($table);

        foreach ($query->result() as $row) {
           foreach($row as $key => $val){
              if( $key != $primary_key_field ) {
                if( $key == 'name' ) { $val .= ' (copy)'; }
                $this->db->set($key, $val);
              }
           }
        }

        /* insert the new record into table*/
        $this->db->insert($table);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

    function delete( $id ){
        $this->db->where('id', $id);
        return $this->db->delete('lists');
    }

    function addProduct( $data ) {
        $this->db->insert('listsmeta', $data);
        $insert_id = $this->db->insert_id();

        return $insert_id;
    }

    function removeProduct( $data ) {
        $array = array('list_id' => $data['list_id'], 'product_id' => $data['product_id']);
        $this->db->where($array);
        return $this->db->delete('listsmeta');
    }

    function getAvailable( $product_id ) {
        $this->db->select('*');
        $this->db->from('listsmeta');
        $this->db->where('product_id', $product_id);

        $query = $this->db->get();

        return ( $query->num_rows() > 0 ) ? $query->result_array() : FALSE;
    }
  }