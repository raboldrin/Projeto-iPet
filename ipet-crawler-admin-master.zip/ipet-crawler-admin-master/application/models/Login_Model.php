<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_Model extends CI_Model {
     function __construct() {
          parent::__construct();
     }

     function get_user($usr, $pwd) {
          $sql = "SELECT * FROM users WHERE username = '" . $usr . "' AND password = '" . md5($pwd) . "' AND status = 'active'";
          $query = $this->db->query($sql);
          return $query->num_rows();
     }
}