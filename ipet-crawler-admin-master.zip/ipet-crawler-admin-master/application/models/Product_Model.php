<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class Product_Model extends CI_Model {
    public function __construct() {
      parent::__construct();

    }

    function getRows( $params = array() ) {
        $this->db->select('*');
        $this->db->from('products');

        $this->db->order_by( 'name' , 'asc' );

        if( array_key_exists( 'start', $params ) && array_key_exists( 'limit', $params ) ) {

            $this->db->limit( $params['limit'], $params['start'] );

        } else if( !array_key_exists( 'start', $params ) && array_key_exists( 'limit', $params ) ) {

            $this->db->limit( $params['limit'] );
        }

        if ( array_key_exists( 'where', $params ) ) {
            $this->db->or_where('slug_category_1', $params['where'] );
            $this->db->or_where('slug_category_2', $params['where'] );
            $this->db->or_where('slug_category_3', $params['where'] );
            $this->db->or_where('slug_brand', $params['where'] );
        }

        $query = $this->db->get();

        return ( $query->num_rows() > 0 ) ? $query->result_array() : FALSE;
    }

    function getEdited( $params = array() ) {

        if ( array_key_exists( 'where', $params ) ) {
        $sql = "SELECT update_date AS edited FROM products WHERE slug_category_1 = ? OR slug_category_2 = ? OR slug_category_3 = ? OR slug_brand = ? AND update_date IS NOT NULL";
        $query = $this->db->query($sql, array( $params['where'], $params['where'], $params['where'], $params['where'] ));
        } else {
            $sql = "SELECT update_date AS edited FROM products where update_date IS NOT NULL";
            $query = $this->db->query($sql);
        }
        return ( $query->num_rows() > 0 ) ? $query->result_array() : 0;

        echo $query;
    }

    function edit( $id ) {
        $this->db->select('*');
        $this->db->from('products');
        $this->db->where('id', $id);

        $query = $this->db->get();

        return ( $query->num_rows() > 0 ) ? $query->result_array() : FALSE;
    }

    function add( $data ) {
        $this->db->insert('products', $data);
        $insert_id = $this->db->insert_id();

        return $insert_id;
    }

    function update( $data, $id ) {
        $this->db->where( 'id', $id );
        $this->db->update('products', $data);
    }

    function getCategories( $cat ) {

        $this->db->select( $cat );
        $this->db->from('products');
        $this->db->order_by( $cat , 'asc' );
        $this->db->group_by( $cat );

        $query = $this->db->get();

        return ( $query->num_rows() > 0 ) ? $query->result_array() : FALSE;
    }

    function copy($table, $primary_key_field, $primary_key_val) {
       /* generate the select query */
       $this->db->where($primary_key_field, $primary_key_val);
       $query = $this->db->get($table);

        foreach ($query->result() as $row) {
           foreach($row as $key => $val){
              if( $key != $primary_key_field ) {
                if( $key == 'name' ) { $val .= ' (copy)'; }
                $this->db->set($key, $val);
              }
           }
        }

        /* insert the new record into table*/
        $this->db->insert($table);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

    function delete( $id ){
        $this->db->where('id', $id);
        return $this->db->delete('products');
    }

  }