<?php
/*
 * jQuery File Upload Plugin PHP Example
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

error_reporting(E_ALL | E_STRICT);
require('UploadHandler.php');


class CustomUploadHandler extends UploadHandler {

    protected function initialize() {
        $this->db = new mysqli(
            'localhost',
            'root',
            'ypsilon2',
            'ipet_crawler'
        );
        parent::initialize();
        $this->db->close();
    }

    protected function handle_form_data($file, $index) {
        $file->customFileName = @$_REQUEST['customFileName'];
        $file->productID = @$_REQUEST['productID'];
    }


    protected function handle_file_upload($uploaded_file, $name, $size, $type, $error,
            $index = null, $content_range = null) {
        $file = new \stdClass();
        $file->name = $this->get_file_name($uploaded_file, $name, $size, $type, $error,
            $index, $content_range);
        $file->size = $this->fix_integer_overflow((int)$size);
        $file->type = $type;
        if ($this->validate($uploaded_file, $file, $error, $index)) {
            $this->handle_form_data($file, $index);
            $file->name = $this->get_file_name($uploaded_file, $file->customFileName, $size, $type, $error,
            $index, $content_range);
            $upload_dir = $this->get_upload_path();
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, $this->options['mkdir_mode'], true);
            }
            $file_path = $this->get_upload_path($file->name);
            $append_file = $content_range && is_file($file_path) &&
                $file->size > $this->get_file_size($file_path);
            if ($uploaded_file && is_uploaded_file($uploaded_file)) {
                // multipart/formdata uploads (POST method uploads)
                if ($append_file) {
                    file_put_contents(
                        $file_path,
                        fopen($uploaded_file, 'r'),
                        FILE_APPEND
                    );
                } else {
                    move_uploaded_file($uploaded_file, $file_path);
                }
            } else {
                // Non-multipart uploads (PUT method support)
                file_put_contents(
                    $file_path,
                    fopen($this->options['input_stream'], 'r'),
                    $append_file ? FILE_APPEND : 0
                );
            }
            $file_size = $this->get_file_size($file_path, $append_file);
            if ($file_size === $file->size) {
                $file->url = $this->get_download_url($file->name);
                if ($this->is_valid_image_file($file_path)) {
                    $this->handle_image_file($file_path, $file);
                }
            } else {
                $file->size = $file_size;
                if (!$content_range && $this->options['discard_aborted_uploads']) {
                    unlink($file_path);
                    $file->error = $this->get_error_message('abort');
                }
            }
            $this->set_additional_file_properties($file);
        }

        if ( empty($file->error) ) {
            $sql = "SELECT `images` FROM `products` WHERE `id` = $file->productID";

            if( $data = $this->db->query($sql) ) {
                while( $row = mysqli_fetch_array( $data ) ) {
                    $images = json_decode( html_entity_decode( $row['images'] ) );
                    $images[] = $file->name;
                    $result = json_encode($images);

                    $sql = "UPDATE `products` SET `images` = '$result' WHERE `id` = $file->productID";
                    $query = $this->db->query($sql);
                }
            }
            $this->db->close();
        }
        return $file;
    }


    public function delete($print_response = true) {
        $response = parent::delete(false);
        $deleted = $response['deleted'];
        $name = $response['name'];
        $product_id = $response['product_id'];

        // foreach ($response as $k => $v) {
            if ($deleted == 1) {
                $sql = "SELECT `images` FROM `products` WHERE `id` = $product_id";

                if( $data = $this->db->query($sql) ) {
                    while( $row = mysqli_fetch_array( $data ) ) {
                        $images = json_decode( html_entity_decode( $row['images'] ) );

                        if( in_array( $name, $images ) ) {
                            if( ( $key = array_search($name, $images) ) !== false) {
                                unset( $images[$key] );
                            }
                        }

                        if( count($images) > 0 ) {
                            $result = '["' . implode('","', $images) . '"]';
                        } else {
                            $result = '[]';
                        }

                        $sql = "UPDATE `products` SET `images` = '$result' WHERE `id` = $product_id";
                        $query = $this->db->query($sql);
                        $this->db->close();
                    }
                }
            }
        // }
        return $this->generate_response($response, $print_response);
    }
}


$upload_handler = new CustomUploadHandler();
